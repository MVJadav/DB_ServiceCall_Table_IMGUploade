//
//  Constant.swift
//  TestDemo
//
//  Created by JadavMac on 20/07/17.
//  Copyright © 2017 MV Jadav. All rights reserved.
//

import Foundation
import UIKit

struct AppColor {
    
    //App Theme Status Bar
    static let Statusbar_Primary        = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.7)
    
    //App Theme
    static let AppTheme_Primary         =  UIColor(red: 0/255, green: 144/255, blue: 255/255, alpha: 0.9)
    static let AppTheme_Secondary       = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.5)
    
    static let Dark_Pink_Secondary      = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 0.5)
    
    //General Light Color
    static let Light_Grey               = UIColor(red: 170/255, green: 170/255, blue: 170/255, alpha: 0.5)
    static let Light_Grey_Group         = UIColor(red: 207/255, green: 207/255, blue: 207/255, alpha: 0.8)
    static let Grey_Saperator           = UIColor(red: 203/255, green: 203/255, blue: 203/255, alpha: 1.0)
    
    //General Dark Color
    static let Dark_Pink                = UIColor(red: 255/255, green: 51/255, blue: 102/255, alpha: 1.0)
    static let Dark_Green               =  UIColor(red: 68/255, green: 175/255, blue: 86/255 , alpha :1.0)
    
    //    static let Dark_Red         =  UIColor(red: 198/255, green: 26/255, blue: 22/255, alpha: 1.0)
    static let Dark_Orange              =  UIColor(red: 209/255, green: 92/255, blue: 50/255, alpha: 1.0)
    static let Dark_Gray                = UIColor(red: 67/255, green: 65/255, blue: 73/255 , alpha :1)
    
    static let Red                      = UIColor.red
    static let Green            = UIColor(red: 41/255, green: 169/255, blue: 88/255, alpha: 1.0)
}

//MARK: permition Message
struct PermitionMessage {
    static let albumTitle = "Allow photo album access?"
    static let albumMessage = "Need your permission to access photo albumbs"
    static let cameraTitle = "Allow camera album access?"
    static let cameraMessage = "Need your permission to take a photo"
    static let bLockPost = "Are you sure you want to block this user?"
    static let deletePost = "Are you sure you want to delete this post?"
    
}
